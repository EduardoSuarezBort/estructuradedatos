#pragma once
#include  "Shape.h"
class Circulo: public Shape
{
public:
	Circulo(void);
	~Circulo(void);
	float getArea() { 
         return (width * width * 3.1416); 
      }
};

