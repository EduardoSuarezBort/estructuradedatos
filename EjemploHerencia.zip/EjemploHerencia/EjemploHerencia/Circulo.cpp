#include "StdAfx.h"
#include "Circulo.h"


Circulo::Circulo(void)
{
}


Circulo::~Circulo(void)
{
}
