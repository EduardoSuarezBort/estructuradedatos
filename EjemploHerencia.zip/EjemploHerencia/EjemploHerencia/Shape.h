#pragma once
// Base class
class Shape {
protected:
      float width;
      float height;   
public:
      void setWidth(float w);
      void setHeight(float h);
};

