#include "StdAfx.h"
#include "Shape.h"


 void Shape::setWidth(float w) {
         width = w;
      }
 void Shape::setHeight(float h) {
         height = h;
      }