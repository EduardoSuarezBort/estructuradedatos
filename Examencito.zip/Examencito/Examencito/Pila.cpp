#include "StdAfx.h"
#include "Pila.h"
#include "Datos.h"


Pila::Pila(void)
{
}

Pila::~Pila(void)
{
}

bool Pila::apilar(Datos dato)
{
	if(puntero==MAX-1)
	{ return false;
	}else
	{ puntero++;
	  vec[puntero] = dato;
	  return true;
	}
}

bool Pila::desapilar()
{
	if(tope==-1)
	{ return false;
	}else
	{ return true;
	}
}

bool Pila::verficar()
{
	if(tope==-1)
	{ return true;
	} else
	{ return false;
	}
}

