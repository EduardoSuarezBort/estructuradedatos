#pragma once
#include <string>
using namespace std;
class Datos
{
public:
	string placa;
	string chasis;
	string marca;
	string modelo;
	int anio;

	Datos(string placa, string modelo, string marca, string chasis, int anio);
	~Datos(void);
};

