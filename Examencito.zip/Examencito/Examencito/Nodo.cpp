#include "StdAfx.h"
#include "Nodo.h"
#include <string>
using namespace std;


Nodo::Nodo(void)
{
	puntero = NULL;
}


Nodo::~Nodo(void)
{
}
