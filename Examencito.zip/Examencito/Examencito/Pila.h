#pragma once
#include "Datos.h"
#include "Nodo.h"
#include <string>
#define MAX 100
using namespace std;

class Pila
{ Nodo *puntero;
public:
	Pila()
	{ puntero=NULL;
	}
	~Pila(void);
	bool apilar(Datos dato);
	bool desapilar();
	bool verficar();
};

