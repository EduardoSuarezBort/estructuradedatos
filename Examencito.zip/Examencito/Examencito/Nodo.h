#pragma once
#define MAX 100
#include <string>
using namespace std;

class Nodo
{
public:
	string placa;
	string chasis;
	string marca;
	string modelo;
	int anio;
	Nodo *puntero;
	Nodo(void);
	~Nodo(void);
};

