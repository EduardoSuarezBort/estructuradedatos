#include "stdafx.h"
#include <string>
#include <iostream>
#include "Datos.h"
#include "Nodo.h"
using namespace std;

void main()
{ int anio,opc;
  string placa, modelo, marca, chasis;

  cout<<"Ingrese la placa: ";
  getline(cin,placa);
  cout<<"Ingrese el modelo: ";
  getline(cin,modelo);
  cout<<"Ingrese la marca: ";
  getline(cin,marca);
  cout<<"Ingrese el chasis: ";
  getline(cin,chasis);
  cout<<"Ingrese el anio: ";
  cin>>anio;

  Datos d1(placa, modelo, marca, chasis, anio);

  do{
  cout<<"----------MENU----------"<<endl;
  cout<<"1.- Apilar"<<endl;
  cout<<"2.- Desapilar"<<endl;
  cout<<"3.- Verificar"<<endl;
  cout<<"4.- Mostrar"<<endl;
  cout<<"0.- Salir"<<endl;
  cout<<"Ingrese una opcion: ";
  cin>>opc;
  }while(opc!=0);

  switch(opc)
  {
  case 1:
	  break;
  case 2:
	  break;
  case 3:
	  break;
  case 4:
	  break;
  case 0:
	  cout<<"Adios";
	  break;
  }


}
