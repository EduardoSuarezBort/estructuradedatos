#include "StdAfx.h"
#include "Datos.h"
#include <string>
using namespace std;

Datos::Datos(string placa, string modelo, string marca, string chasis, int anio)
{
	placa="Unknow";
	chasis="Unknow";
	marca="Unknow";
	modelo="Unknow";
	anio=0;
}

Datos::~Datos(void)
{
}
